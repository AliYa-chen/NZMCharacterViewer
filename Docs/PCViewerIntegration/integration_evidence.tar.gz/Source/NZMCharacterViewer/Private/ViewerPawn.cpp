#include "ViewerPawn.h"
#include "ViewerWidget.h"
#include "ViewerSmokeTestComponent.h"
#include "ViewerEnvironment.h"
#include "ViewerDynamics.h"
#include "ViewerIOSViewport.h"
#include "Camera/CameraComponent.h"
#include "Camera/PlayerCameraManager.h"
#include "Animation/AnimSequence.h"
#include "Components/DirectionalLightComponent.h"
#include "Components/ExponentialHeightFogComponent.h"
#include "Components/InputComponent.h"
#include "Components/PointLightComponent.h"
#include "Components/LocalLightComponent.h"
#include "Components/RectLightComponent.h"
#include "Components/SpotLightComponent.h"
#include "Components/SkyLightComponent.h"
#include "Components/LightComponent.h"
#include "Components/PostProcessComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/SkeletalMesh.h"
#include "Engine/AssetManager.h"
#include "Engine/StreamableManager.h"
#include "Engine/StaticMesh.h"
#include "Engine/Texture2D.h"
#include "Engine/Texture.h"
#include "Engine/TextureCube.h"
#include "Engine/World.h"
#include "GameFramework/PlayerController.h"
#include "InputCoreTypes.h"
#include "Materials/MaterialInterface.h"
#include "MaterialShaderPrecompileMode.h"
#include "HAL/PlatformTime.h"
#include "HAL/IConsoleManager.h"
#include "Misc/CommandLine.h"
#include "Misc/Parse.h"
#include "RHI.h"
#include "DataDrivenShaderPlatformInfo.h"
#include "SceneInterface.h"

AViewerPawn::AViewerPawn()
{
    PrimaryActorTick.bCanEverTick = true;
    RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
    SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
    SceneRoot->SetupAttachment(RootComponent);
    ModelRoot = CreateDefaultSubobject<USceneComponent>(TEXT("ModelRoot"));
    ModelRoot->SetupAttachment(SceneRoot);
    PreparingRoot = CreateDefaultSubobject<USceneComponent>(TEXT("PreparingRoot"));
    PreparingRoot->SetupAttachment(RootComponent);
    Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera"));
    Camera->SetupAttachment(RootComponent);
    Camera->FieldOfView = 29.9281126f;
    Camera->bConstrainAspectRatio = false;
    Camera->bOverrideAspectRatioAxisConstraint = true;
    Camera->AspectRatioAxisConstraint = AspectRatio_MaintainXFOV;
    AutoPossessPlayer = EAutoReceiveInput::Player0;
}

void AViewerPawn::BeginPlay()
{
    Super::BeginPlay();
    SetActorLocationAndRotation(FVector::ZeroVector, FRotator::ZeroRotator);
    Preferences = UViewerPreferences::Load();
#if !UE_BUILD_SHIPPING
    // Compare a renderer initialized with MSAA to a live AA-mode transition.
    // This development override never writes the saved preference object.
    int32 StartupMSAA = 0;
    if (FParse::Param(FCommandLine::Get(), TEXT("ViewerLightingBootMSAA")) &&
        FParse::Value(FCommandLine::Get(), TEXT("ViewerLightingMSAA="), StartupMSAA) &&
        StartupMSAA > 1 && UViewerPreferences::AntialiasingSamples().Contains(StartupMSAA))
    {
        Preferences->bScreenSpaceReflections = false;
        Preferences->Antialiasing = StartupMSAA;
    }
    if (FParse::Param(FCommandLine::Get(), TEXT("ViewerLightingTAA")))
    {
        // Interactive comparison without starting the automated lighting sweep.
        // These startup settings are applied in memory, never persisted here.
        Preferences->Antialiasing = 0;
    }
    if (FParse::Param(FCommandLine::Get(), TEXT("ViewerLightingSSR")))
    {
        Preferences->bPostProcessing = true;
        Preferences->bScreenSpaceReflections = true;
        Preferences->Antialiasing = 0;
    }
    else if (FParse::Param(FCommandLine::Get(), TEXT("ViewerLightingNoSSR")))
        Preferences->bScreenSpaceReflections = false;
#endif
    Environment = LoadObject<UViewerEnvironment>(nullptr,
        TEXT("/Game/Viewer/Environment/DA_Environment.DA_Environment"));
    if (!Environment)
        UE_LOG(LogTemp, Error, TEXT("Original role environment is missing. Run Scripts/refresh_assets.py; the temporary stage does not reproduce Scene103."));
    ApplyPreferences();
    Catalog = LoadObject<UViewerCatalog>(nullptr, TEXT("/Game/Viewer/Data/DA_ViewerCatalog.DA_ViewerCatalog"));
    LoadSelection();
    InitializeInterface();
    UpdateCamera();
#if !UE_BUILD_SHIPPING
    if (FParse::Param(FCommandLine::Get(), TEXT("ViewerSmokeTest")) ||
        FParse::Param(FCommandLine::Get(), TEXT("ViewerLightingSweep")))
    {
        SmokeTest = NewObject<UViewerSmokeTestComponent>(this);
        SmokeTest->RegisterComponent();
        SmokeTest->Start(this);
    }
#endif
}

void AViewerPawn::InitializeInterface()
{
    if (ViewerUI) return;
    if (APlayerController* PC = Cast<APlayerController>(GetController()))
    {
        PC->bShowMouseCursor = true;
        PC->bEnableTouchEvents = true;
        FInputModeGameAndUI Mode;
        Mode.SetHideCursorDuringCapture(false);
        Mode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
        PC->SetInputMode(Mode);
        ViewerUI = CreateWidget<UViewerWidget>(PC, UViewerWidget::StaticClass());
        if (ViewerUI)
        {
            ViewerUI->InitializeViewer(this);
            ViewerUI->AddToViewport();
        }
    }
}

void AViewerPawn::SetupPlayerInputComponent(UInputComponent* Input)
{
    Super::SetupPlayerInputComponent(Input);
    Input->BindAxisKey(EKeys::MouseWheelAxis, this, &AViewerPawn::Zoom);
}

void AViewerPawn::Tick(float DeltaSeconds)
{
    Super::Tick(DeltaSeconds);
    ViewerIOSViewport::Tick();
    InitializeInterface();
    TickSelectionPreparation();
    if (!bPreparingSelection && (!SmokeTest || !SmokeTest->IsRunning())) ReadPointerInput();
    DisplayYaw = FMath::FixedTurn(DisplayYaw, Yaw, FMath::Min(DeltaSeconds, 0.05f) * 540.f);
    // Orbit the complete stage with the camera. Rotating geometry and local
    // lights instead leaves specified HDR lighting in a different world frame.
    // The development switch preserves that old path for device comparisons.
    bool bLegacyTurntable = false;
#if !UE_BUILD_SHIPPING
    bLegacyTurntable = FParse::Param(FCommandLine::Get(), TEXT("ViewerLegacyTurntable"));
#endif
    SceneRoot->SetRelativeRotation(bLegacyTurntable ? FRotator(0.f, DisplayYaw, 0.f) : FRotator::ZeroRotator);
    UpdateCamera();
}

const FViewerOutfit* AViewerPawn::GetCurrentOutfit() const
{
    if (!Catalog || !Catalog->Characters.IsValidIndex(CharacterIndex)) return nullptr;
    const FViewerCharacter& Character = Catalog->Characters[CharacterIndex];
    return Character.Outfits.IsValidIndex(OutfitIndex) ? &Character.Outfits[OutfitIndex] : nullptr;
}

const FViewerOutfit* AViewerPawn::GetActiveOutfit() const
{
    if (!Catalog || !Catalog->Characters.IsValidIndex(ActiveCharacterIndex)) return nullptr;
    const FViewerCharacter& Character = Catalog->Characters[ActiveCharacterIndex];
    return Character.Outfits.IsValidIndex(ActiveOutfitIndex) ? &Character.Outfits[ActiveOutfitIndex] : nullptr;
}

void AViewerPawn::ReleaseSelection()
{
    for (USkeletalMeshComponent* Part : Parts)
    {
        if (!Part) continue;
        Part->Stop();
        Part->SetAnimation(nullptr);
        Part->SetSkeletalMesh(nullptr);
        Part->EmptyOverrideMaterials();
        Part->DestroyComponent();
    }
    Parts.Reset();
    if (ActiveHandle) ActiveHandle->ReleaseHandle();
    ActiveHandle.Reset();
}

void AViewerPawn::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
    if (SmokeTest) SmokeTest->Stop();
    ++SelectionGeneration;
    CancelSelectionPreparation();
    if (PrefetchHandle) PrefetchHandle->ReleaseHandle();
    PrefetchHandle.Reset();
    ReleaseSelection();
    ClearStage();
    RestoreSourceConsoleVariables();
    if (ViewerUI) ViewerUI->RemoveFromParent();
    ViewerUI = nullptr;
    Super::EndPlay(EndPlayReason);
}

namespace
{
    void AddViewerOutfitAssets(const FViewerOutfit& Outfit, TArray<FSoftObjectPath>& Assets)
    {
        Assets.AddUnique(Outfit.Environment.IsNull()
            ? FSoftObjectPath(TEXT("/Game/Viewer/Environment/DA_Environment.DA_Environment"))
            : Outfit.Environment.ToSoftObjectPath());
        for (const FViewerPart& Part : Outfit.Parts)
        {
            if (!Part.Mesh.IsNull()) Assets.AddUnique(Part.Mesh.ToSoftObjectPath());
            if (!Part.Animation.IsNull()) Assets.AddUnique(Part.Animation.ToSoftObjectPath());
            if (!Part.Dynamics.IsNull()) Assets.AddUnique(Part.Dynamics.ToSoftObjectPath());
            for (const auto& Material : Part.Materials)
                if (!Material.IsNull()) Assets.AddUnique(Material.ToSoftObjectPath());
        }
    }

    void AddViewerEnvironmentAssets(const UViewerEnvironment& Stage, TArray<FSoftObjectPath>& Assets)
    {
        if (!Stage.Cubemap.IsNull()) Assets.AddUnique(Stage.Cubemap.ToSoftObjectPath());
        for (const auto& Mesh : Stage.Meshes)
        {
            if (!Mesh.Mesh.IsNull()) Assets.AddUnique(Mesh.Mesh.ToSoftObjectPath());
            for (const auto& Material : Mesh.Materials)
                if (!Material.IsNull()) Assets.AddUnique(Material.ToSoftObjectPath());
        }
    }
}

void AViewerPawn::CancelSelectionPreparation()
{
    if (LoadingHandle) LoadingHandle->CancelHandle();
    LoadingHandle.Reset();
    for (USkeletalMeshComponent* Part : PreparingParts) if (Part) Part->DestroyComponent();
    PreparingParts.Reset();
    for (UStaticMeshComponent* Mesh : PreparingStageMeshes) if (Mesh) Mesh->DestroyComponent();
    PreparingStageMeshes.Reset();
    PreparingMaterials.Reset();
    PreparingTextures.Reset();
    PreparingEnvironment = nullptr;
    bPreparingSelection = bEnvironmentDependenciesRequested = bPreparationTexturesRequested = false;
    bPreparationComponentsBuilt = bPreparationFenceStarted = false;
    PreparingRoot->SetRelativeTransform(FTransform::Identity);
}

void AViewerPawn::FailSelectionPreparation(const FText& FailureStatus)
{
    UE_LOG(LogTemp, Warning, TEXT("Viewer selection %d/%d generation %d failed: %s"),
        CharacterIndex, OutfitIndex, SelectionGeneration, *FailureStatus.ToString());
    CancelSelectionPreparation();
    // The old meshes remain visible when preparation fails. Restore their
    // catalog selection too, so labels/part controls agree and retry is possible.
    if (ActiveCharacterIndex != INDEX_NONE)
    {
        CharacterIndex = ActiveCharacterIndex;
        OutfitIndex = ActiveOutfitIndex;
    }
    Status = FailureStatus;
    if (ViewerUI) ViewerUI->Refresh();
}

void AViewerPawn::LoadSelection()
{
    const int32 Generation = ++SelectionGeneration;
    UE_LOG(LogTemp, Display, TEXT("Viewer selection requested %d/%d generation %d"), CharacterIndex, OutfitIndex, Generation);
    CancelSelectionPreparation();
    const FViewerOutfit* Outfit = GetCurrentOutfit();
    if (!Outfit)
    {
        FailSelectionPreparation(FText::FromString(TEXT("尚未导入人物资源。请先运行编辑器导入脚本。")));
        return;
    }
    // The previous scene and character remain visible until the replacement
    // has passed shader, texture, PSO and render-resource readiness checks.
    bPreparingSelection = true;
    bLastSelectionReadyBeforeVisible = false;
    PreparationStartedSeconds = FPlatformTime::Seconds();
    LastPreparationWaitLogSeconds = PreparationStartedSeconds;
    Status = FText::FromString(TEXT("正在载入角色与场景…"));
    if (ViewerUI) ViewerUI->Refresh();
    TArray<FSoftObjectPath> Assets;
    AddViewerOutfitAssets(*Outfit, Assets);
    LoadingHandle = UAssetManager::GetStreamableManager().RequestAsyncLoad(Assets,
        FStreamableDelegate::CreateUObject(this, &AViewerPawn::FinishSelectionLoad, Generation));
    if (PrefetchHandle) PrefetchHandle->ReleaseHandle();
    PrefetchHandle.Reset();
    if (!LoadingHandle)
    {
        FailSelectionPreparation(FText::FromString(TEXT("无法开始载入，当前角色已保留。")));
    }
}

void AViewerPawn::FinishSelectionLoad(int32 Generation)
{
    if (Generation != SelectionGeneration || !bPreparingSelection) return;
    const FViewerOutfit* Outfit = GetCurrentOutfit();
    if (!Outfit) return;
    if (!bEnvironmentDependenciesRequested)
    {
        PreparingEnvironment = Outfit->Environment.IsNull()
            ? LoadObject<UViewerEnvironment>(nullptr, TEXT("/Game/Viewer/Environment/DA_Environment.DA_Environment"))
            : Outfit->Environment.Get();
        if (!PreparingEnvironment)
        {
            FailSelectionPreparation(FText::FromString(TEXT("无法完整载入场景，当前角色已保留。")));
            return;
        }
        bEnvironmentDependenciesRequested = true;
        TArray<FSoftObjectPath> Assets;
        AddViewerOutfitAssets(*Outfit, Assets);
        AddViewerEnvironmentAssets(*PreparingEnvironment, Assets);
        LoadingHandle = UAssetManager::GetStreamableManager().RequestAsyncLoad(Assets,
            FStreamableDelegate::CreateUObject(this, &AViewerPawn::FinishSelectionLoad, Generation));
        if (!LoadingHandle)
            FailSelectionPreparation(FText::FromString(TEXT("无法开始载入场景资源，当前角色已保留。")));
        return;
    }
    auto AddMaterial = [this](UMaterialInterface* Material)
    {
        if (!Material || PreparingMaterials.Contains(Material)) return;
        PreparingMaterials.Add(Material);
#if WITH_EDITOR
        // Editor -game can load an incomplete shader map without submitting
        // its missing permutations. Schedule that work once before the gate;
        // complete/shared resources must not be recached on every selection.
        if (!Material->IsCompiling() && !Material->IsComplete())
            Material->CacheShaders(EMaterialShaderPrecompileMode::Background);
#endif
    };
    bool Valid = true;
    for (const FViewerPart& Part : Outfit->Parts)
    {
        Valid &= Part.Mesh.Get() && (Part.Animation.IsNull() || Part.Animation.Get());
        // PC imports keep their source bindings on the mesh. A Catalog part
        // may therefore have no override array; those native materials still
        // need shader and texture preparation before it becomes visible.
        if (const USkeletalMesh* Mesh = Part.Mesh.Get())
            for (const FSkeletalMaterial& Slot : Mesh->GetMaterials())
                AddMaterial(Slot.MaterialInterface);
        for (const auto& Material : Part.Materials)
        {
            // A source slot may intentionally be empty. Only a nonempty
            // reference that failed to load is an incomplete selection.
            Valid &= Material.IsNull() || Material.Get() != nullptr;
            AddMaterial(Material.Get());
        }
    }
    auto ValidateStage = [&Valid, &AddMaterial](const UViewerEnvironment* Stage)
    {
        if (!Stage) return;
        for (const auto& Mesh : Stage->Meshes)
        {
            Valid &= Mesh.Mesh.Get() != nullptr;
            for (const auto& Material : Mesh.Materials)
            {
                Valid &= Material.Get() != nullptr;
                AddMaterial(Material.Get());
            }
        }
        Valid &= Stage->Cubemap.Get() != nullptr;
    };
    ValidateStage(PreparingEnvironment);
    if (!Valid)
    {
        FailSelectionPreparation(FText::FromString(TEXT("资源未能完整载入，当前角色已保留。")));
    }
}

void AViewerPawn::BuildPreparingComponents()
{
    const FViewerOutfit* Outfit = GetCurrentOutfit();
    if (!Outfit || !PreparingEnvironment) return;
    PreparingRoot->SetRelativeTransform(PreparingEnvironment->ModelTransform);
    for (const FViewerPart& Part : Outfit->Parts)
    {
        UViewerSkeletalMeshComponent* Component = NewObject<UViewerSkeletalMeshComponent>(this);
        Component->SetupAttachment(PreparingRoot);
        Component->SetRelativeTransform(Part.RelativeTransform);
        Component->SetCollisionEnabled(ECollisionEnabled::NoCollision);
        Component->SetVisibility(false, true);
        Component->SetSkeletalMesh(Part.Mesh.Get());
        Component->SetAnimationMode(EAnimationMode::AnimationSingleNode);
        Component->SetCastShadow(true);
        const int32 ChannelMask = PreparingEnvironment->bUseSourceRendering
            ? PreparingEnvironment->CharacterLightingChannelMask : 3;
        Component->SetLightingChannels((ChannelMask & 1) != 0, (ChannelMask & 2) != 0, (ChannelMask & 4) != 0);
        // Bind every material before registration; never register a visible
        // mesh with the importer's temporary/default material slots.
        for (int32 Slot = 0; Slot < Part.Materials.Num(); ++Slot)
            Component->SetMaterial(Slot, Part.Materials[Slot].Get());
        Component->RegisterComponent();
        Component->SetDynamicsProfile(Part.Dynamics.Get());
        Component->SetSecondaryMotionEnabled(Preferences && Preferences->bSecondaryMotion);
        Component->VisibilityBasedAnimTickOption = EVisibilityBasedAnimTickOption::AlwaysTickPoseAndRefreshBones;
        if (Part.Animation.Get())
        {
            Component->PlayAnimation(Part.Animation.Get(), Part.bAnimationLoop);
            Component->TickAnimation(0.f, false);
            Component->RefreshBoneTransforms();
        }
        Component->PrestreamTextures(180.f, true);
        Component->PrecachePSOs();
        Component->UpdateBounds();
        PreparingParts.Add(Component);
    }
    // Separate accessory skeletons (for example rabbit ears and leg wheels)
    // are authored in socket-local space, rather than the avatar's bind space.
    for (int32 Index = 0; Index < Outfit->Parts.Num(); ++Index)
    {
        const FViewerPart& Part = Outfit->Parts[Index];
        if (Part.ParentPartId.IsNone()) continue;
        const int32 ParentIndex = Outfit->Parts.IndexOfByPredicate([&Part](const FViewerPart& Candidate)
        { return Candidate.Id == Part.ParentPartId; });
        if (!PreparingParts.IsValidIndex(ParentIndex) || ParentIndex == Index ||
            Part.AttachSocket.IsNone() || !PreparingParts[ParentIndex]->DoesSocketExist(Part.AttachSocket))
        {
            FailSelectionPreparation(FText::FromString(TEXT("无法使用附件挂点，当前角色已保留。")));
            return;
        }
        USkeletalMeshComponent* Parent = PreparingParts[ParentIndex];
        USkeletalMeshComponent* Child = PreparingParts[Index];
        Child->AttachToComponent(Parent, FAttachmentTransformRules::KeepRelativeTransform, Part.AttachSocket);
        Child->SetRelativeTransform(Part.RelativeTransform);
        Child->AddTickPrerequisiteComponent(Parent);
        Child->UpdateBounds();
    }
    for (const FViewerEnvironmentMesh& Spec : PreparingEnvironment->Meshes)
    {
        UStaticMeshComponent* Component = NewObject<UStaticMeshComponent>(this);
        Component->ComponentTags.Add(Spec.Id);
        Component->SetupAttachment(GetRootComponent());
        Component->SetMobility(EComponentMobility::Movable);
        Component->SetVisibility(false, true);
        Component->SetStaticMesh(Spec.Mesh.Get());
        Component->SetRelativeTransform(Spec.Transform);
        Component->SetCollisionEnabled(ECollisionEnabled::NoCollision);
        Component->SetCastShadow(Spec.bCastShadows);
        for (int32 Index = 0; Index < Spec.Materials.Num(); ++Index)
            Component->SetMaterial(Index, Spec.Materials[Index].Get());
        Component->RegisterComponent();
        Component->PrestreamTextures(180.f, false);
        Component->PrecachePSOs();
        PreparingStageMeshes.Add(Component);
    }
    bPreparationComponentsBuilt = true;
}

void AViewerPawn::TickSelectionPreparation()
{
    if (!bPreparingSelection || !LoadingHandle) return;
    const auto Waiting = [this](const TCHAR* Reason, const UObject* Asset = nullptr)
    {
        const double Now = FPlatformTime::Seconds();
        if (Now - LastPreparationWaitLogSeconds < 10.0) return;
        LastPreparationWaitLogSeconds = Now;
        UE_LOG(LogTemp, Display, TEXT("Viewer preparing generation %d: waiting for %s %s (%.1fs)"),
            SelectionGeneration, Reason, Asset ? *Asset->GetPathName() : TEXT(""), Now - PreparationStartedSeconds);
    };
    if (FPlatformTime::Seconds() - PreparationStartedSeconds > 120.0)
    {
        FailSelectionPreparation(FText::FromString(TEXT("无法完成资源准备，当前角色已保留。")));
        return;
    }
    if (!LoadingHandle->HasLoadCompleted() || !bEnvironmentDependenciesRequested || !PreparingEnvironment
        || PreparingMaterials.IsEmpty()) { Waiting(TEXT("asynchronous package dependencies")); return; }
    const FViewerOutfit* Outfit = GetCurrentOutfit();
    if (!Outfit) return;
    for (const FViewerPart& Part : Outfit->Parts)
    {
        if (!Part.Mesh.Get() || Part.Mesh.Get()->IsCompiling() || Part.Mesh.Get()->HasPendingInitOrStreaming())
        { Waiting(TEXT("skeletal mesh resources"), Part.Mesh.Get()); return; }
        if (Part.Animation.Get() && !Part.Animation.Get()->IsCompressedDataValid())
        { Waiting(TEXT("animation compression"), Part.Animation.Get()); return; }
    }
    for (const auto& Spec : PreparingEnvironment->Meshes)
        if (!Spec.Mesh.Get() || Spec.Mesh.Get()->IsCompiling() || Spec.Mesh.Get()->HasPendingInitOrStreaming())
        { Waiting(TEXT("static mesh resources"), Spec.Mesh.Get()); return; }
    for (UMaterialInterface* Material : PreparingMaterials)
        if (!Material || Material->IsCompiling() || !Material->IsComplete())
        { Waiting(TEXT("material shaders"), Material); return; }
    if (!bPreparationTexturesRequested)
    {
        for (UMaterialInterface* Material : PreparingMaterials)
        {
            TArray<UTexture*> UsedTextures;
            Material->GetUsedTextures(UsedTextures);
            for (UTexture* Texture : UsedTextures) PreparingTextures.AddUnique(Texture);
        }
        PreparingTextures.AddUnique(PreparingEnvironment->Cubemap.Get());
        for (UTexture* Texture : PreparingTextures)
            if (Texture) Texture->SetForceMipLevelsToBeResident(180.f);
        bPreparationTexturesRequested = true;
    }
    if (!bPreparationComponentsBuilt) BuildPreparingComponents();
    if (!bPreparingSelection) return;
    for (UTexture* Texture : PreparingTextures)
        if (!Texture || Texture->IsCompiling() || !Texture->GetResource() || Texture->HasPendingInitOrStreaming()
            || (Texture->IsStreamable() && !Texture->IsFullyStreamedIn()))
        { Waiting(TEXT("resident texture mips"), Texture); return; }
    for (USkeletalMeshComponent* Part : PreparingParts) if (Part->IsPSOPrecaching())
    { Waiting(TEXT("skeletal mesh PSOs"), Part); return; }
    for (UStaticMeshComponent* Mesh : PreparingStageMeshes) if (Mesh->IsPSOPrecaching())
    { Waiting(TEXT("static mesh PSOs"), Mesh); return; }
    if (!bPreparationFenceStarted)
    {
        PreparationFence.BeginFence(FRenderCommandFence::ESyncDepth::RHIThread);
        bPreparationFenceStarted = true;
        return;
    }
    if (!PreparationFence.IsFenceComplete()) { Waiting(TEXT("RHI submission fence")); return; }
    CommitPreparedSelection();
}

void AViewerPawn::CommitPreparedSelection()
{
    const FViewerOutfit* Outfit = GetCurrentOutfit();
    if (!Outfit) return;
    LastSelectionPreparationSeconds = FPlatformTime::Seconds() - PreparationStartedSeconds;
    ReleaseSelection();
    ClearStage();
    SceneRoot->SetRelativeRotation(FRotator::ZeroRotator);
    Environment = PreparingEnvironment;
    StageMeshes = MoveTemp(PreparingStageMeshes);
    for (UStaticMeshComponent* Mesh : StageMeshes)
        Mesh->AttachToComponent(SceneRoot, FAttachmentTransformRules::KeepRelativeTransform);
    CreateStage(true);
    TObjectPtr<USceneComponent> OldRoot = ModelRoot;
    ModelRoot = PreparingRoot;
    PreparingRoot = OldRoot;
    ModelRoot->AttachToComponent(SceneRoot, FAttachmentTransformRules::KeepRelativeTransform);
    PreparingRoot->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepRelativeTransform);
    PreparingRoot->SetRelativeTransform(FTransform::Identity);
    Parts = MoveTemp(PreparingParts);
    // Settings may have changed after hidden preparation components were built.
    // Apply them to the adopted parts, rather than the released old selection.
    ApplyPreferences();
    ActiveCharacterIndex = CharacterIndex;
    ActiveOutfitIndex = OutfitIndex;
    ActiveHandle = MoveTemp(LoadingHandle);
    FBox Bounds(ForceInit);
    FBox PoseBounds(ForceInit);
    FramingBounds = FBox(ForceInit);
    const FVector PreviousModelLocation = ModelRoot->GetComponentLocation();
    for (int32 Index = 0; Index < Parts.Num(); ++Index)
    {
        USkeletalMeshComponent* Component = Parts[Index];
        Component->SetVisibility(Outfit->Parts[Index].bVisibleByDefault, true);
        Component->PrestreamTextures(3.f, true);
        Component->UpdateBounds();
        // Renderer bounds include the evaluated pose plus a conservative
        // margin for culling. Keep the existing reference-mesh framing/ground
        // normalization independent of that margin, or standing feet float.
        if (Outfit->Parts[Index].bVisibleByDefault && Component->GetSkeletalMeshAsset())
        {
            Bounds += Component->GetSkeletalMeshAsset()->GetBounds()
                .TransformBy(Component->GetComponentTransform()).GetBox();
            // Use one evaluated idle pose for composition. The renderer's box
            // also includes the reference pose and can dwarf a seated avatar.
            if (Outfit->Parts[Index].Animation.Get())
            {
                Component->SetPosition(0.f, false);
                Component->TickAnimation(0.f, false);
                Component->RefreshBoneTransforms();
            }
            FBox PartPoseBounds(ForceInit);
            const TArray<FTransform>& Pose = Component->GetComponentSpaceTransforms();
            // Only anatomy describes the subject. Cape, skirt, weapon and
            // presentation controls can sit metres beyond the visible body.
            static const FName Landmarks[] = {
                TEXT("b_Hips"), TEXT("b_Spine"), TEXT("b_Spine1"), TEXT("b_Spine2"),
                TEXT("b_Neck"), TEXT("b_Head"),
                TEXT("b_LeftClav"), TEXT("b_LeftArm"), TEXT("b_LeftForeArm"), TEXT("b_LeftHand"),
                TEXT("b_RightClav"), TEXT("b_RightArm"), TEXT("b_RightForeArm"), TEXT("b_RightHand"),
                TEXT("b_LeftLegUpper"), TEXT("b_LeftLeg"), TEXT("b_LeftAnkle"), TEXT("b_LeftToe"),
                TEXT("b_RightLegUpper"), TEXT("b_RightLeg"), TEXT("b_RightAnkle"), TEXT("b_RightToe") };
            for (const FName BoneName : Landmarks)
            {
                const int32 BoneIndex = Component->GetBoneIndex(BoneName);
                if (!Pose.IsValidIndex(BoneIndex)) continue;
                const FVector Position = Component->GetComponentTransform().TransformPosition(Pose[BoneIndex].GetLocation());
                if (!Position.ContainsNaN())
                {
                    PartPoseBounds += Position;
                    if (BoneName == FName(TEXT("b_Head"))) PartPoseBounds += Position + FVector(0.f, 0.f, 12.f);
                }
            }
            // Socket-local accessories are part of the visible silhouette.
            // Anatomy alone omits tall rabbit ears and leg-mounted wheels.
            if (!Outfit->Parts[Index].ParentPartId.IsNone())
                PartPoseBounds += Component->GetSkeletalMeshAsset()->GetBounds()
                    .TransformBy(Component->GetComponentTransform()).GetBox();
            if (PartPoseBounds.IsValid) PoseBounds += PartPoseBounds.ExpandBy(8.f);
        }
    }
    for (UStaticMeshComponent* Mesh : StageMeshes) { Mesh->SetVisibility(true, true); Mesh->PrestreamTextures(3.f, false); }
    PreparingMaterials.Reset();
    PreparingTextures.Reset();
    PreparingEnvironment = nullptr;
    bPreparingSelection = false;
    bLastSelectionReadyBeforeVisible = true;
    UE_LOG(LogTemp, Display, TEXT("Viewer prepared selection published: %s, %.3fs, %d character parts, %d scene meshes; materials/textures/PSOs ready before visibility"),
        *Outfit->Id.ToString(), LastSelectionPreparationSeconds, Parts.Num(), StageMeshes.Num());
    if (Bounds.IsValid)
    {
        ModelHeight = FMath::Max(50.f, Bounds.GetSize().Z);
        ModelWidth = FMath::Max(20.f, FMath::Max(Bounds.GetSize().X, Bounds.GetSize().Y));
        const FVector Center = Bounds.GetCenter();
        ModelRoot->SetRelativeLocation(Environment && Environment->bPreserveModelOrigin
            ? Environment->ModelTransform.GetLocation() : FVector(-Center.X, -Center.Y, -Bounds.Min.Z));
        const FVector NormalizationOffset = ModelRoot->GetComponentLocation() - PreviousModelLocation;
        FramingBounds = (PoseBounds.IsValid ? PoseBounds : Bounds).ShiftBy(NormalizationOffset);
        UE_LOG(LogTemp, Display, TEXT("Viewer stable pose framing: center=%s, size=%s, evaluated pose=%s"),
            *FramingBounds.GetCenter().ToString(), *FramingBounds.GetSize().ToString(), PoseBounds.IsValid ? TEXT("yes") : TEXT("no"));
        Focus = FVector(0.f, 0.f, ModelHeight * 0.72f);
        if (Environment && Environment->bFrameFromHeadBone)
        {
            // Keep the source pose and its relationship to the stage. Move
            // the view to the face instead of moving the model or throne.
            for (USkeletalMeshComponent* Part : Parts)
            {
                if (Part && Part->GetBoneIndex(TEXT("b_Head")) != INDEX_NONE)
                {
                    Focus = Part->GetBoneLocation(TEXT("b_Head")) - FVector(0.f, 0.f, 17.f);
                    ModelHeight = 180.f;
                    ModelWidth = 90.f;
                    break;
                }
            }
        }
        DefaultDistance = Environment && Environment->bUseSourceCamera ? Environment->CameraDistance
            : (Environment ? Environment->CameraDistance : 350.f) * ModelHeight / 180.f;
        LastViewportSize = FVector2D::ZeroVector;
    }
    ResetView();
    ReplayAnimation();
    if (ViewerUI) ViewerUI->Refresh();
    PrefetchAdjacentCharacter();
}


void AViewerPawn::PrefetchAdjacentCharacter()
{
    if (!Catalog || Catalog->Characters.Num() < 2) return;
    const int32 Next = (CharacterIndex + 1) % Catalog->Characters.Num();
    if (Catalog->Characters[Next].Outfits.IsEmpty()) return;
    const int32 Generation = SelectionGeneration;
    TArray<FSoftObjectPath> Assets;
    AddViewerOutfitAssets(Catalog->Characters[Next].Outfits[0], Assets);
    PrefetchHandle = UAssetManager::GetStreamableManager().RequestAsyncLoad(Assets,
        FStreamableDelegate::CreateWeakLambda(this, [this, Generation, Next, Assets]() mutable
        {
            if (Generation != SelectionGeneration || !Catalog || bPreparingSelection) return;
            const auto& Outfit = Catalog->Characters[Next].Outfits[0];
            UViewerEnvironment* Stage = Outfit.Environment.IsNull()
                ? LoadObject<UViewerEnvironment>(nullptr, TEXT("/Game/Viewer/Environment/DA_Environment.DA_Environment"))
                : Outfit.Environment.Get();
            if (Stage) AddViewerEnvironmentAssets(*Stage, Assets);
            PrefetchHandle = UAssetManager::GetStreamableManager().RequestAsyncLoad(Assets);
        }));
}

void AViewerPawn::ChangeCharacter(int32 Direction)
{
    if (!Catalog || Catalog->Characters.Num() < 2) return;
    SelectCharacter((CharacterIndex + Direction + Catalog->Characters.Num()) % Catalog->Characters.Num());
}

void AViewerPawn::ChangeOutfit(int32 Direction)
{
    if (!HasMultipleOutfits()) return;
    const int32 Count = Catalog->Characters[CharacterIndex].Outfits.Num();
    SelectOutfit((OutfitIndex + Direction + Count) % Count);
}

void AViewerPawn::SelectCharacter(int32 Index)
{
    if (!Catalog || !Catalog->Characters.IsValidIndex(Index) ||
        (CharacterIndex == Index && (bPreparingSelection || ActiveCharacterIndex == Index))) return;
    CharacterIndex = Index;
    OutfitIndex = 0;
    LoadSelection();
}

void AViewerPawn::SelectOutfit(int32 Index)
{
    if (!Catalog || !Catalog->Characters.IsValidIndex(CharacterIndex) ||
        (OutfitIndex == Index && (bPreparingSelection ||
            (ActiveCharacterIndex == CharacterIndex && ActiveOutfitIndex == Index))) ||
        !Catalog->Characters[CharacterIndex].Outfits.IsValidIndex(Index)) return;
    OutfitIndex = Index;
    LoadSelection();
}

TArray<FString> AViewerPawn::GetCharacterOptions() const
{
    TArray<FString> Options;
    if (!Catalog) return Options;
    for (int32 Index = 0; Index < Catalog->Characters.Num(); ++Index)
        Options.Add(FString::Printf(TEXT("%02d  %s"), Index + 1, *Catalog->Characters[Index].DisplayName.ToString()));
    return Options;
}

TArray<FString> AViewerPawn::GetOutfitOptions() const
{
    TArray<FString> Options;
    if (!Catalog || !Catalog->Characters.IsValidIndex(CharacterIndex)) return Options;
    const auto& Outfits = Catalog->Characters[CharacterIndex].Outfits;
    for (int32 Index = 0; Index < Outfits.Num(); ++Index)
        Options.Add(FString::Printf(TEXT("%02d  %s"), Index + 1, *Outfits[Index].DisplayName.ToString()));
    return Options;
}

void AViewerPawn::ResetView()
{
    Yaw = 0.f;
    DisplayYaw = 0.f;
    SceneRoot->SetRelativeRotation(FRotator::ZeroRotator);
    Pitch = Environment ? Environment->CameraPitch : 4.4f;
    Distance = DefaultDistance;
    bPointerDragging = false;
    bPinching = false;
    for (USkeletalMeshComponent* Part : Parts)
        if (UViewerSkeletalMeshComponent* Dynamic = Cast<UViewerSkeletalMeshComponent>(Part)) Dynamic->ResetSecondaryMotion();
    UpdateCamera();
    InvalidateViewHistory();
}

void AViewerPawn::InvalidateViewHistory()
{
    // A new composition, renderer choice or reset cannot reuse the old view's
    // temporal samples. Ordinary drag frames keep their history for TAA.
    if (APlayerController* PC = Cast<APlayerController>(GetController()))
        if (PC->PlayerCameraManager) PC->PlayerCameraManager->SetGameCameraCutThisFrame();
}

void AViewerPawn::SetPartVisible(int32 Index, bool bVisible)
{
    if (bPreparingSelection) return;
    // Attached accessories remain independently selectable in the parts list.
    if (Parts.IsValidIndex(Index) && Parts[Index]) Parts[Index]->SetVisibility(bVisible, false);
}

bool AViewerPawn::IsPartVisible(int32 Index) const
{
    return Parts.IsValidIndex(Index) && Parts[Index] && Parts[Index]->IsVisible();
}

bool AViewerPawn::IsPartLoaded(int32 Index) const
{
    // GetCurrentOutfit describes the pending selection while old Parts remain
    // on screen. Do not bind its part controls to the old character's indexes.
    return !bPreparingSelection && Parts.IsValidIndex(Index) && Parts[Index] != nullptr;
}

void AViewerPawn::Orbit(FVector2D Delta)
{
    int32 Width = 0, Height = 0;
    if (const APlayerController* PC = Cast<APlayerController>(GetController()))
        PC->GetViewportSize(Width, Height);
    // Input arrives in physical pixels. Match the same gesture across the
    // folded/unfolded displays instead of amplifying it at native resolution.
    const float Scale = 720.f / FMath::Max(1, FMath::Min(Width, Height));
    Yaw = FMath::UnwindDegrees(Yaw - Delta.X * Scale * 0.22f);
    Pitch = FMath::Clamp(Pitch - Delta.Y * Scale * 0.18f, -30.f, 65.f);
}

void AViewerPawn::Zoom(float Amount)
{
    if (ViewerUI)
    {
        if (APlayerController* PC = Cast<APlayerController>(GetController()))
        {
            float X = 0.f, Y = 0.f;
            if (PC->GetMousePosition(X, Y) && ViewerUI->BlocksModelInput(FVector2D(X, Y))) return;
        }
    }
    Distance = FMath::Clamp(Distance * FMath::Exp(-Amount * 0.12f), ModelHeight * 0.6f, DefaultDistance * 2.2f);
}

void AViewerPawn::ReadPointerInput()
{
    APlayerController* PC = Cast<APlayerController>(GetController());
    if (!PC) return;
    float X1 = 0.f, Y1 = 0.f, X2 = 0.f, Y2 = 0.f;
    bool First = false, Second = false;
    PC->GetInputTouchState(ETouchIndex::Touch1, X1, Y1, First);
    PC->GetInputTouchState(ETouchIndex::Touch2, X2, Y2, Second);
    const FVector2D Point1(X1, Y1), Point2(X2, Y2);
    // Consume the entire touch gesture, including a second finger added after
    // dismissing settings. Release the guard only after every finger lifts.
    if ((First || Second) && ViewerUI && ViewerUI->ConsumeModalPointer(First ? Point1 : Point2, true))
    {
        bPinching = bPointerDragging = false;
        return;
    }
    if (First && Second)
    {
        if (ViewerUI && (ViewerUI->BlocksModelInput(Point1) || ViewerUI->BlocksModelInput(Point2)))
        {
            bPinching = bPointerDragging = false;
            return;
        }
        const float Separation = FVector2D::Distance(Point1, Point2);
        if (bPinching && PreviousPinch > 1.f && Separation > 1.f)
            Distance = FMath::Clamp(Distance * PreviousPinch / Separation, ModelHeight * 0.6f, DefaultDistance * 2.2f);
        PreviousPinch = Separation;
        bPinching = true;
        bPointerDragging = false;
        return;
    }
    if (bPinching) { bPinching = false; bPointerDragging = false; }
    FVector2D Pointer = Point1;
    bool Pressed = First;
    if (!First)
    {
        float MouseX = 0.f, MouseY = 0.f;
        Pressed = PC->GetMousePosition(MouseX, MouseY) && PC->IsInputKeyDown(EKeys::LeftMouseButton);
        Pointer = FVector2D(MouseX, MouseY);
    }
    if (ViewerUI && ViewerUI->ConsumeModalPointer(Pointer, Pressed))
    {
        bPointerDragging = false;
        return;
    }
    if (!Pressed || (ViewerUI && ViewerUI->BlocksModelInput(Pointer)))
    {
        bPointerDragging = false;
        return;
    }
    if (bPointerDragging) Orbit(Pointer - PreviousPointer);
    PreviousPointer = Pointer;
    bPointerDragging = true;
}

void AViewerPawn::UpdateCamera()
{
    int32 Width = 0, Height = 0;
    if (const APlayerController* PC = Cast<APlayerController>(GetController())) PC->GetViewportSize(Width, Height);
    if (Width <= 0 || Height <= 0) return;
    const float Aspect = static_cast<float>(Width) / Height;
    Camera->AspectRatio = Aspect;
    const FVector2D Size(Width, Height);
    FBox2D Available = ViewerUI ? ViewerUI->GetModelViewportRect() : FBox2D(ForceInit);
    if (!Available.bIsValid || Available.GetSize().GetMin() < 64.0)
        Available = FBox2D(FVector2D::ZeroVector, Size);
    const bool bLayoutChanged = !Size.Equals(LastViewportSize, 0.5) || !LastModelViewportRect.bIsValid ||
        !Available.Min.Equals(LastModelViewportRect.Min, 0.5) || !Available.Max.Equals(LastModelViewportRect.Max, 0.5);
    if (bLayoutChanged)
    {
        const bool bSourceCamera = Environment && Environment->bUseSourceCamera;
        const float BasePitch = Environment ? Environment->CameraPitch : 4.4f;
        const float BaseYaw = Environment ? Environment->CameraYaw : -90.f;
        const FRotator BaseRotation = bSourceCamera ? Environment->SourceCameraTransform.Rotator()
            : FRotator(BasePitch, BaseYaw, 0.f);
        // Keep the source camera inside its preview room. Fit by projection and
        // direction, rather than retreating through furniture or background walls.
        FramingCameraLocation = bSourceCamera ? Environment->SourceCameraTransform.GetLocation()
            : Focus - BaseRotation.Vector() * DefaultDistance;
        const bool bExactSourceCamera = bSourceCamera && Environment->bUseSourceRendering
            && FParse::Param(FCommandLine::Get(), TEXT("ViewerPCSourceCamera"));
        if (bExactSourceCamera)
        {
            // A comparison capture uses the serialized camera rotation and FOV.
            // The normal interactive view below fits the available UI rectangle.
            FramingCameraRotation = Environment->SourceCameraTransform.Rotator();
            FramingHorizontalFOV = Environment->CameraHorizontalFOV;
        }
        else
        {
        const FBox FitBounds = FramingBounds.IsValid ? FramingBounds
            : FBox(Focus - FVector(ModelWidth * 0.5f, ModelWidth * 0.5f, ModelHeight * 0.5f),
                Focus + FVector(ModelWidth * 0.5f, ModelWidth * 0.5f, ModelHeight * 0.5f));
        const FQuat LookAtCenter = (FitBounds.GetCenter() - FramingCameraLocation).Rotation().Quaternion();
        const FVector2D DesiredCenter(Available.GetCenter().X * 2.0 / Width - 1.0,
            1.0 - Available.GetCenter().Y * 2.0 / Height);
        // Keep a margin around the stable anatomical pose. Every candidate
        // rotation is rebuilt from the same look-at, never accumulated Euler
        // corrections that can drift or diverge near a steep source camera.
        const FVector2D HalfCoverage(Available.GetSize().X / Width * 0.8,
            Available.GetSize().Y / Height * 0.8);
        auto RotationForTangent = [&](double Tangent)
        {
            const FVector DesiredRay = FVector(1.0, DesiredCenter.X * Tangent,
                DesiredCenter.Y * Tangent / Aspect).GetSafeNormal();
            return LookAtCenter * FQuat::FindBetweenNormals(DesiredRay, FVector::ForwardVector);
        };
        auto Fits = [&](double Tangent)
        {
            const FQuat InverseRotation = RotationForTangent(Tangent).Inverse();
            for (int32 Corner = 0; Corner < 8; ++Corner)
            {
                const FVector Position((Corner & 1) ? FitBounds.Max.X : FitBounds.Min.X,
                    (Corner & 2) ? FitBounds.Max.Y : FitBounds.Min.Y,
                    (Corner & 4) ? FitBounds.Max.Z : FitBounds.Min.Z);
                const FVector Local = InverseRotation.RotateVector(Position - FramingCameraLocation);
                if (Local.X <= 5.0) return false;
                const FVector2D Projected(Local.Y / (Local.X * Tangent),
                    Local.Z * Aspect / (Local.X * Tangent));
                if (FMath::Abs(Projected.X - DesiredCenter.X) > HalfCoverage.X ||
                    FMath::Abs(Projected.Y - DesiredCenter.Y) > HalfCoverage.Y) return false;
            }
            return true;
        };
        double MinimumTangent = FMath::Tan(FMath::DegreesToRadians(7.5));
        double MaximumTangent = FMath::Tan(FMath::DegreesToRadians(50.0));
        // Bounded scalar search: each test projects the complete box into the
        // intended rectangle, including asymmetric perspective at close range.
        for (int32 Iteration = 0; Iteration < 24; ++Iteration)
        {
            const double Candidate = (MinimumTangent + MaximumTangent) * 0.5;
            if (Fits(Candidate)) MaximumTangent = Candidate;
            else MinimumTangent = Candidate;
        }
        FramingCameraRotation = RotationForTangent(MaximumTangent).Rotator();
        FramingHorizontalFOV = FMath::RadiansToDegrees(2.0 * FMath::Atan(MaximumTangent));
        }
        LastViewportSize = Size;
        LastModelViewportRect = Available;
        InvalidateViewHistory();
        UE_LOG(LogTemp, Display, TEXT("Viewer viewport changed: %dx%d, aspect %.4f, fitted FOV %.3f, model area (%.0f,%.0f)-(%.0f,%.0f)"),
            Width, Height, Aspect, FramingHorizontalFOV, Available.Min.X, Available.Min.Y, Available.Max.X, Available.Max.Y);
    }
    const float ZoomRatio = DefaultDistance > 1.f ? Distance / DefaultDistance : 1.f;
    Camera->FieldOfView = FMath::Clamp(FMath::RadiansToDegrees(2.f * FMath::Atan(
        FMath::Tan(FMath::DegreesToRadians(FramingHorizontalFOV * 0.5f)) * ZoomRatio)), 8.f, 110.f);
    FRotator Rotation = FramingCameraRotation;
    Rotation.Pitch += Pitch - (Environment ? Environment->CameraPitch : 4.4f);
    Camera->SetWorldLocationAndRotation(FramingCameraLocation, Rotation);
    bool bLegacyTurntable = false;
#if !UE_BUILD_SHIPPING
    bLegacyTurntable = FParse::Param(FCommandLine::Get(), TEXT("ViewerLegacyTurntable"));
#endif
    if (!bLegacyTurntable)
    {
        const FQuat OrbitRotation(FVector::UpVector, FMath::DegreesToRadians(-DisplayYaw));
        const FVector Pivot = FramingBounds.IsValid ? FramingBounds.GetCenter() : SceneRoot->GetComponentLocation();
        const float PitchDelta = Pitch - (Environment ? Environment->CameraPitch : 4.4f);
        const FQuat PitchOrbit(FramingCameraRotation.Quaternion().GetRightVector(), -FMath::DegreesToRadians(PitchDelta));
        const FQuat Orbit = OrbitRotation * PitchOrbit;
        Camera->SetWorldLocationAndRotation(Pivot + Orbit.RotateVector(FramingCameraLocation - Pivot),
            Orbit * FramingCameraRotation.Quaternion());
    }
    if (StagePostProcess && Preferences && Preferences->bDepthOfField
        && (!Environment || !Environment->bUseSourceRendering))
        StagePostProcess->Settings.DepthOfFieldFocalDistance = FramingBounds.IsValid
            ? FVector::Distance(FramingCameraLocation, FramingBounds.GetCenter()) : DefaultDistance;
}

FText AViewerPawn::GetCharacterLabel() const
{
    return Catalog && Catalog->Characters.IsValidIndex(CharacterIndex)
        ? Catalog->Characters[CharacterIndex].DisplayName : FText::FromString(TEXT("人物尚未导入"));
}
FText AViewerPawn::GetOutfitLabel() const
{
    const FViewerOutfit* Outfit = GetCurrentOutfit();
    return Outfit ? Outfit->DisplayName : FText::FromString(TEXT("暂无服装"));
}
FText AViewerPawn::GetStatusLabel() const { return Status; }
bool AViewerPawn::HasMultipleCharacters() const { return Catalog && Catalog->Characters.Num() > 1; }
bool AViewerPawn::HasMultipleOutfits() const
{
    return Catalog && Catalog->Characters.IsValidIndex(CharacterIndex) && Catalog->Characters[CharacterIndex].Outfits.Num() > 1;
}

int32 AViewerPawn::GetCharacterCount() const { return Catalog ? Catalog->Characters.Num() : 0; }

FText AViewerPawn::GetCharacterDisplayName(int32 Index) const
{
    return Catalog && Catalog->Characters.IsValidIndex(Index) ? Catalog->Characters[Index].DisplayName : FText::GetEmpty();
}

UTexture2D* AViewerPawn::GetCharacterPortrait(int32 Index) const
{
    return Catalog && Catalog->Characters.IsValidIndex(Index)
        ? Catalog->Characters[Index].Portrait.LoadSynchronous() : nullptr;
}

void AViewerPawn::SetPreferenceChoice(EViewerSetting Setting, int32 Index)
{
    if (!Preferences) return;
    Preferences->SetChoice(Setting, Index);
    ApplyPreferences();
    Preferences->Persist();
    if (ViewerUI) ViewerUI->Refresh();
}

void AViewerPawn::SetPreferenceToggle(EViewerSetting Setting, bool bEnabled)
{
    if (!Preferences) return;
    Preferences->SetToggle(Setting, bEnabled);
    ApplyPreferences();
    Preferences->Persist();
    if (ViewerUI) ViewerUI->Refresh();
}

void AViewerPawn::ResetPreferences()
{
    if (!Preferences) return;
    Preferences->ResetDefaults();
    ApplyPreferences();
    Preferences->Persist();
    if (ViewerUI) ViewerUI->Refresh();
}

void AViewerPawn::ReplayAnimation()
{
    const FViewerOutfit* Outfit = GetActiveOutfit();
    if (!Outfit) return;
    for (int32 Index = 0; Index < Parts.Num() && Outfit->Parts.IsValidIndex(Index); ++Index)
    {
        USkeletalMeshComponent* Component = Parts[Index];
        if (!Component) continue;
        const FViewerPart& Part = Outfit->Parts[Index];
        Component->SetRelativeTransform(Part.RelativeTransform);
        if (UAnimSequence* Animation = Part.Animation.Get())
        {
            Component->PlayAnimation(Animation, Part.bAnimationLoop);
            Component->SetPosition(0.f, false);
            Component->TickAnimation(0.f, false);
            Component->RefreshBoneTransforms();
        }
        else { Component->Stop(); Component->SetAnimation(nullptr); }
        if (UViewerSkeletalMeshComponent* Dynamic = Cast<UViewerSkeletalMeshComponent>(Component))
            Dynamic->ResetSecondaryMotion();
    }
    if (!bPreparingSelection)
    {
        const bool bHasAnimation = Outfit->Parts.ContainsByPredicate([](const FViewerPart& Part) { return !Part.Animation.IsNull(); });
        Status = Outfit->PreviewNotes.IsEmpty()
            ? FText::FromString(bHasAnimation ? TEXT("待机动作 · 可分部件查看") : TEXT("原始绑定姿势 · 可分部件查看"))
            : Outfit->PreviewNotes;
        if (ViewerUI) ViewerUI->Refresh();
    }
}

void AViewerPawn::ApplyPreferences()
{
    if (!Preferences) return;
    RestoreSourceConsoleVariables();
    const bool bSourceRendering = Environment && Environment->bUseSourceRendering;
    Preferences->ApplyEngineSettings(bSourceRendering);
    InvalidateViewHistory();
    if (bSourceRendering) ApplySourceRenderingPreferences();
    if (StagePostProcess && !bSourceRendering)
    {
        FPostProcessSettings& Post = StagePostProcess->Settings;
        if (Environment) Post = Environment->PostProcess;
        Post.bOverride_AutoExposureMethod = true;
        Post.AutoExposureMethod = EAutoExposureMethod::AEM_Manual;
        Post.bOverride_AutoExposureApplyPhysicalCameraExposure = true;
        Post.AutoExposureApplyPhysicalCameraExposure = false;
        Post.bOverride_BloomIntensity = true;
        Post.BloomIntensity = Preferences->bPostProcessing && Preferences->bBloom
            ? Environment ? Environment->PostProcess.BloomIntensity : 0.15f : 0.f;
        Post.bOverride_VignetteIntensity = true;
        Post.VignetteIntensity = Preferences->bPostProcessing && Preferences->bVignette
            ? Environment ? Environment->PostProcess.VignetteIntensity : 0.25f : 0.f;
        Post.bOverride_DepthOfFieldScale = true;
        Post.DepthOfFieldScale = Preferences->bPostProcessing && Preferences->bDepthOfField ? 1.f : 0.f;
        Post.bOverride_DepthOfFieldFstop = true;
        Post.DepthOfFieldFstop = 2.8f;
        Post.bOverride_DepthOfFieldFocalDistance = true;
        Post.DepthOfFieldFocalDistance = Distance;
        Post.bOverride_AmbientOcclusionIntensity = true;
        // Keep the environment's calibrated contact shading. Forcing 1 here
        // doubled the imported value and dirtied faces and clothing folds.
        Post.AmbientOcclusionIntensity = Preferences->bPostProcessing && Preferences->bAmbientOcclusion
            ? Environment ? Environment->PostProcess.AmbientOcclusionIntensity : 0.45f : 0.f;
        Post.bOverride_AmbientOcclusionQuality = true;
        Post.AmbientOcclusionQuality = 100.f;
        Post.bOverride_ScreenSpaceReflectionIntensity = true;
        Post.ScreenSpaceReflectionIntensity = Preferences->bPostProcessing && Preferences->bScreenSpaceReflections ? 100.f : 0.f;
        Post.bOverride_ScreenSpaceReflectionQuality = true;
        Post.ScreenSpaceReflectionQuality = 100.f;
        Post.bOverride_ScreenSpaceReflectionMaxRoughness = true;
        Post.ScreenSpaceReflectionMaxRoughness = .8f;
        const bool bMobile = IsMobilePlatform(GMaxRHIShaderPlatform);
        Post.bOverride_DynamicGlobalIlluminationMethod = true;
        Post.DynamicGlobalIlluminationMethod = !bMobile && Preferences->bPostProcessing
            ? EDynamicGlobalIlluminationMethod::Lumen : EDynamicGlobalIlluminationMethod::None;
        Post.bOverride_ReflectionMethod = true;
        Post.ReflectionMethod = Preferences->bPostProcessing && Preferences->bScreenSpaceReflections
            ? EReflectionMethod::ScreenSpace
            : EReflectionMethod::None;
        if (!bMobile)
        {
            Post.bOverride_LumenSceneLightingQuality = true;
            Post.LumenSceneLightingQuality = 2.f;
            Post.bOverride_LumenSceneDetail = true;
            Post.LumenSceneDetail = 2.f;
            Post.bOverride_LumenFinalGatherQuality = true;
            Post.LumenFinalGatherQuality = 2.f;
        }
        if (!Preferences->bPostProcessing)
        {
            Post.bOverride_ColorContrast = true;
            Post.ColorContrast = FVector4(1.f, 1.f, 1.f, 1.f);
            Post.bOverride_ColorSaturation = true;
            Post.ColorSaturation = FVector4(1.f, 1.f, 1.f, 1.f);
            Post.bOverride_ColorContrastMidtones = true;
            Post.ColorContrastMidtones = FVector4(1.f, 1.f, 1.f, 1.f);
        }
    }
    if (StageFog) StageFog->SetVisibility(Preferences->bPostProcessing);
    for (ULightComponent* Light : StageLights)
    {
        if (!Light) continue;
        const FViewerEnvironmentLight* Source = Environment ? Environment->Lights.FindByPredicate(
            [Light](const FViewerEnvironmentLight& Spec) { return Light->ComponentHasTag(Spec.Id); }) : nullptr;
        Light->SetCastShadows(Preferences->Shadows > 0 && (!Source || Source->bCastShadows));
    }
    for (USkeletalMeshComponent* Part : Parts)
        if (UViewerSkeletalMeshComponent* Dynamic = Cast<UViewerSkeletalMeshComponent>(Part))
            Dynamic->SetSecondaryMotionEnabled(Preferences->bSecondaryMotion);
}

void AViewerPawn::RestoreSourceConsoleVariables()
{
    for (const auto& Value : SourceConsoleRestoreValues)
        if (IConsoleVariable* Variable = IConsoleManager::Get().FindConsoleVariable(*Value.Key.ToString()))
            Variable->Set(Value.Value, ECVF_SetByGameOverride);
    SourceConsoleRestoreValues.Reset();
}

void AViewerPawn::ApplySourceRenderingPreferences()
{
    if (!Environment || !Preferences) return;
    const bool bMobile = UViewerPreferences::UsesMobileRenderer();
    const TMap<FName, float>& Variables = bMobile
        ? Environment->MobileSourceConsoleVariables : Environment->SourceConsoleVariables;
    for (const auto& Value : Variables)
    {
        const FString Name = Value.Key.ToString();
        IConsoleVariable* Variable = IConsoleManager::Get().FindConsoleVariable(*Name);
        if (!Name.StartsWith(TEXT("r.")) || !Variable || !FMath::IsFinite(Value.Value)
            || Variable->TestFlags(ECVF_ReadOnly))
        {
            UE_LOG(LogTemp, Warning, TEXT("PC source rendering variable unavailable at runtime: %s"), *Name);
            continue;
        }
        SourceConsoleRestoreValues.Add(Value.Key, Variable->GetFloat());
        Variable->Set(Value.Value, ECVF_SetByGameOverride);
    }
    const auto DisableVariable = [](const TCHAR* Name)
    {
        if (IConsoleVariable* Variable = IConsoleManager::Get().FindConsoleVariable(Name))
            Variable->Set(0.f, ECVF_SetByGameOverride);
    };
    if (!Preferences->bPostProcessing || !Preferences->bBloom) DisableVariable(TEXT("r.BloomQuality"));
    if (!Preferences->bPostProcessing || !Preferences->bDepthOfField) DisableVariable(TEXT("r.DepthOfFieldQuality"));
    if (!Preferences->bPostProcessing || !Preferences->bAmbientOcclusion)
    {
        DisableVariable(TEXT("r.AmbientOcclusionLevels"));
        DisableVariable(TEXT("r.Mobile.AmbientOcclusionQuality"));
    }
    if (!Preferences->bPostProcessing || !Preferences->bScreenSpaceReflections || Preferences->Antialiasing != 0)
        DisableVariable(TEXT("r.SSR.Quality"));
    if (!StagePostProcess) return;
    FPostProcessSettings& Post = StagePostProcess->Settings;
    Post = bMobile && Environment->bHasMobilePostProcess
        ? Environment->MobilePostProcess : Environment->PostProcess;
    StagePostProcess->bEnabled = Environment->bSourcePostEnabled;
    StagePostProcess->bUnbound = Environment->bSourcePostUnbound;
    StagePostProcess->Priority = Environment->SourcePostPriority;
    StagePostProcess->BlendWeight = Environment->SourcePostBlendWeight;
    // Enabled features keep both the source value and its source override bit.
    // User switches can disable a feature without creating a new artistic preset.
    if (!Preferences->bPostProcessing || !Preferences->bBloom)
    { Post.bOverride_BloomIntensity = true; Post.BloomIntensity = 0.f; }
    if (!Preferences->bPostProcessing || !Preferences->bVignette)
    { Post.bOverride_VignetteIntensity = true; Post.VignetteIntensity = 0.f; }
    if (!Preferences->bPostProcessing || !Preferences->bDepthOfField)
    { Post.bOverride_DepthOfFieldScale = true; Post.DepthOfFieldScale = 0.f; }
    if (!Preferences->bPostProcessing || !Preferences->bAmbientOcclusion)
    { Post.bOverride_AmbientOcclusionIntensity = true; Post.AmbientOcclusionIntensity = 0.f; }
    if (!Preferences->bPostProcessing || !Preferences->bScreenSpaceReflections)
    {
        Post.bOverride_ScreenSpaceReflectionIntensity = true;
        Post.ScreenSpaceReflectionIntensity = 0.f;
        Post.bOverride_ReflectionMethod = true;
        Post.ReflectionMethod = EReflectionMethod::None;
    }
    if (!Preferences->bPostProcessing)
    {
        Post.bOverride_LensFlareIntensity = true; Post.LensFlareIntensity = 0.f;
        Post.bOverride_SceneFringeIntensity = true; Post.SceneFringeIntensity = 0.f;
        Post.bOverride_ColorContrast = true; Post.ColorContrast = FVector4(1.f);
        Post.bOverride_ColorSaturation = true; Post.ColorSaturation = FVector4(1.f);
        Post.bOverride_ColorContrastMidtones = true; Post.ColorContrastMidtones = FVector4(1.f);
    }
}

void AViewerPawn::ClearStage()
{
    for (UStaticMeshComponent* Mesh : StageMeshes) if (Mesh) Mesh->DestroyComponent();
    StageMeshes.Reset();
    for (ULightComponent* Light : StageLights) if (Light) Light->DestroyComponent();
    StageLights.Reset();
    if (StageSky) StageSky->DestroyComponent();
    StageSky = nullptr;
    if (StageFog) StageFog->DestroyComponent();
    StageFog = nullptr;
    if (StagePostProcess) StagePostProcess->DestroyComponent();
    StagePostProcess = nullptr;
}

void AViewerPawn::LoadOutfitEnvironment(const FViewerOutfit& Outfit)
{
    UViewerEnvironment* Requested = Outfit.Environment.IsNull()
        ? LoadObject<UViewerEnvironment>(nullptr, TEXT("/Game/Viewer/Environment/DA_Environment.DA_Environment"))
        : Outfit.Environment.LoadSynchronous();
    if (!Requested)
    {
        UE_LOG(LogTemp, Error, TEXT("Role environment unavailable for outfit %s: %s"), *Outfit.Id.ToString(), *Outfit.Environment.ToString());
        return;
    }
    if (Requested == Environment) return;
    ClearStage();
    Environment = Requested;
    CreateStage();
    ApplyPreferences();
    LastViewportSize = FVector2D::ZeroVector;
}

void AViewerPawn::CreateStage(bool bUsePreparedMeshes)
{
    USceneComponent* Root = SceneRoot;
#if !PLATFORM_IOS
    const bool bSourceFog = Environment && Environment->bUseSourceRendering && Environment->bUseSourceFog;
    const bool bFogScatteringRequested = bSourceFog || (Environment && Environment->bEnableFogScattering)
        || FParse::Param(FCommandLine::Get(), TEXT("ViewerFogScattering"));
    const FSceneInterface* Scene = GetWorld() ? GetWorld()->Scene : nullptr;
    const bool bDesktopFogSupported = Scene && Scene->GetFeatureLevel() >= ERHIFeatureLevel::SM5
        && !IsMobilePlatform(Scene->GetShaderPlatform());
    if (bFogScatteringRequested && bDesktopFogSupported)
    {
        StageFog = NewObject<UExponentialHeightFogComponent>(this);
        StageFog->SetupAttachment(Root);
        StageFog->SetMobility(EComponentMobility::Movable);
        if (bSourceFog) StageFog->SetRelativeTransform(Environment->FogTransform);
        StageFog->SetFogDensity(bSourceFog ? Environment->FogDensity
            : FMath::Clamp(Environment ? Environment->FogDensity : 0.003f, 0.f, 0.05f));
        StageFog->SetFogHeightFalloff(FMath::Clamp(Environment ? Environment->FogHeightFalloff : 0.2f, 0.001f, 2.f));
        StageFog->SetStartDistance(FMath::Max(0.f, Environment ? Environment->FogStartDistance : 100.f));
        StageFog->SetFogInscatteringColor(Environment ? Environment->FogColor : FLinearColor(0.04f, 0.055f, 0.075f));
        StageFog->SetFogMaxOpacity(bSourceFog ? Environment->FogMaxOpacity : 1.f);
        StageFog->SetVolumetricFog(bSourceFog ? Environment->bSourceVolumetricFog : true);
        StageFog->SetVolumetricFogAlbedo(bSourceFog ? FColor::White : FColor(180, 180, 180));
        StageFog->SetVolumetricFogScatteringDistribution(bSourceFog
            ? Environment->FogVolumetricScatteringDistribution : 0.2f);
        StageFog->SetVolumetricFogDistance(bSourceFog ? Environment->FogVolumetricDistance : 1200.f);
        StageFog->SetVolumetricFogStartDistance(FMath::Max(0.f, Environment ? Environment->FogStartDistance : 100.f));
        // Conservative native FSSS controls keep the character readable. The
        // renderer's separate fog composition still decides actual pass support.
        StageFog->bEnableFSSS = !bSourceFog;
        StageFog->FSSSSceneColorScatteringAmountScale = 0.15f;
        StageFog->FSSSSceneColorScatteringAmountPower = 1.f;
        StageFog->FSSSSpreadScale = 0.15f;
        StageFog->FSSSBlurControl = 0.35f;
        StageFog->SetVisibility(!Preferences || Preferences->bPostProcessing);
        StageFog->RegisterComponent();
        UE_LOG(LogTemp, Display, TEXT("Native stage fog scattering requested: density=%.4f; start=%.1fcm; feature level=%d"),
            StageFog->FogDensity, StageFog->StartDistance, static_cast<int32>(Scene->GetFeatureLevel()));
    }
    else if (bFogScatteringRequested)
        UE_LOG(LogTemp, Display, TEXT("Native stage fog scattering skipped: requires a desktop SM5+ scene."));
#endif
    if (Environment)
    {
        if (!bUsePreparedMeshes) for (const FViewerEnvironmentMesh& Spec : Environment->Meshes)
        {
            UStaticMesh* Mesh = Spec.Mesh.LoadSynchronous();
            if (!Mesh)
            {
                UE_LOG(LogTemp, Error, TEXT("Role environment mesh failed to load: %s"), *Spec.Mesh.ToString());
                continue;
            }
            UStaticMeshComponent* Component = NewObject<UStaticMeshComponent>(this);
            Component->ComponentTags.Add(Spec.Id);
            Component->SetupAttachment(Root);
            Component->SetMobility(EComponentMobility::Movable);
            Component->SetStaticMesh(Mesh);
            Component->SetRelativeTransform(Spec.Transform);
            Component->SetCollisionEnabled(ECollisionEnabled::NoCollision);
            Component->SetCastShadow(Spec.bCastShadows);
            for (int32 Index = 0; Index < Spec.Materials.Num(); ++Index)
                if (UMaterialInterface* Material = Spec.Materials[Index].LoadSynchronous()) Component->SetMaterial(Index, Material);
            Component->RegisterComponent();
            StageMeshes.Add(Component);
        }
        USkyLightComponent* Sky = NewObject<USkyLightComponent>(this);
        StageSky = Sky;
        Sky->SetupAttachment(Root);
        Sky->SetMobility(EComponentMobility::Movable);
        Sky->SourceType = SLS_SpecifiedCubemap;
        Sky->SetCubemap(Environment->Cubemap.LoadSynchronous());
        Sky->SetIntensity(Environment->SkyIntensity);
        Sky->SetLightColor(Environment->SkyColor);
        Sky->SetCastShadows(Environment->bUseSourceRendering && Environment->bSkyCastShadows);
        if (Environment->bUseSourceRendering)
        {
            Sky->SetSourceCubemapAngle(Environment->SkyCubemapAngle);
            Sky->VolumetricScatteringIntensity = Environment->SkyVolumetricScatteringIntensity;
        }
        Sky->RegisterComponent();
        UE_LOG(LogTemp, Display, TEXT("Role environment: %s; meshes=%d; HDR=%s; source lights=%d"),
            *Environment->GetPathName(), StageMeshes.Num(), *GetPathNameSafe(Sky->Cubemap), Environment->Lights.Num());
        for (const FViewerEnvironmentLight& Spec : Environment->Lights)
        {
            const bool bSourceRendering = Environment->bUseSourceRendering;
            ULightComponent* Light = Spec.Kind == TEXT("Directional")
                ? static_cast<ULightComponent*>(NewObject<UDirectionalLightComponent>(this))
                : Spec.Kind == TEXT("Point") ? static_cast<ULightComponent*>(NewObject<UPointLightComponent>(this))
                : Spec.Kind == TEXT("Rect") ? static_cast<ULightComponent*>(NewObject<URectLightComponent>(this))
                : static_cast<ULightComponent*>(NewObject<USpotLightComponent>(this));
            Light->ComponentTags.Add(Spec.Id);
            Light->SetupAttachment(Root);
            Light->SetMobility(bSourceRendering
                ? static_cast<EComponentMobility::Type>(FMath::Clamp(Spec.Mobility, 0, 2)) : EComponentMobility::Movable);
            Light->SetRelativeLocationAndRotation(Spec.Location, Spec.Rotation);
            if (bSourceRendering)
            {
                Light->SetRelativeScale3D(Spec.Scale);
                Light->SetVisibility(Spec.bVisible);
                Light->bAffectsWorld = Spec.bAffectsWorld;
                Light->ShadowResolutionScale = Spec.ShadowResolutionScale;
                Light->SetIndirectLightingIntensity(Spec.IndirectLightingIntensity);
                Light->SetVolumetricScatteringIntensity(Spec.VolumetricScatteringIntensity);
            }
            Light->SetLightingChannels((Spec.LightingChannelMask & 1) != 0,
                (Spec.LightingChannelMask & 2) != 0, (Spec.LightingChannelMask & 4) != 0);
            if (UDirectionalLightComponent* Directional = Cast<UDirectionalLightComponent>(Light))
            {
                // This is a small character stage: spend shadow texels around
                // the subject rather than the engine's outdoor default range.
                Directional->DynamicShadowDistanceMovableLight = bSourceRendering ? Spec.DynamicShadowDistance : 1600.f;
                Directional->DynamicShadowCascades = bSourceRendering ? Spec.DynamicShadowCascades : 3;
                Directional->CascadeDistributionExponent = bSourceRendering ? Spec.CascadeDistributionExponent : 2.f;
                Directional->CascadeTransitionFraction = bSourceRendering ? Spec.CascadeTransitionFraction : 0.15f;
            }
            if (ULocalLightComponent* Local = Cast<ULocalLightComponent>(Light))
            {
                Local->SetIntensityUnits(static_cast<ELightUnits>(Spec.IntensityUnits));
                Local->SetAttenuationRadius(Spec.Radius);
            }
            if (UPointLightComponent* Local = Cast<UPointLightComponent>(Light))
            {
                Local->SetUseInverseSquaredFalloff(Spec.bInverseSquaredFalloff);
                Local->SetLightFalloffExponent(Spec.FalloffExponent);
                Local->SetSourceRadius(Spec.SourceRadius);
                Local->SetSourceLength(Spec.SourceLength);
            }
            if (URectLightComponent* Rect = Cast<URectLightComponent>(Light))
            {
                Rect->SetSourceWidth(Spec.SourceWidth);
                Rect->SetSourceHeight(Spec.SourceHeight);
                Rect->SetBarnDoorAngle(Spec.BarnDoorAngle);
                Rect->SetBarnDoorLength(Spec.BarnDoorLength);
            }
            if (USpotLightComponent* Spot = Cast<USpotLightComponent>(Light))
            {
                Spot->SetInnerConeAngle(Spec.InnerCone);
                Spot->SetOuterConeAngle(Spec.OuterCone);
            }
            Light->SetIntensity(Spec.Intensity);
            Light->SetLightColor(Spec.Color);
            Light->SetTemperature(Spec.Temperature);
            Light->bUseTemperature = Spec.bUseTemperature;
            Light->SetSpecularScale(Spec.SpecularScale);
            Light->SetShadowBias(Spec.ShadowBias);
            Light->SetCastShadows(Spec.bCastShadows);
            Light->RegisterComponent();
            StageLights.Add(Light);
        }
        StagePostProcess = NewObject<UPostProcessComponent>(this);
        StagePostProcess->SetupAttachment(Root);
        const bool bSourceRendering = Environment->bUseSourceRendering;
        StagePostProcess->bUnbound = !bSourceRendering || Environment->bSourcePostUnbound;
        StagePostProcess->bEnabled = !bSourceRendering || Environment->bSourcePostEnabled;
        StagePostProcess->Priority = bSourceRendering ? Environment->SourcePostPriority : 0.f;
        StagePostProcess->BlendWeight = bSourceRendering ? Environment->SourcePostBlendWeight : 1.f;
        StagePostProcess->Settings = bSourceRendering && UViewerPreferences::UsesMobileRenderer()
            && Environment->bHasMobilePostProcess ? Environment->MobilePostProcess : Environment->PostProcess;
        StagePostProcess->RegisterComponent();
        return;
    }
    UStaticMeshComponent* Plinth = NewObject<UStaticMeshComponent>(this);
    Plinth->SetupAttachment(Root);
    Plinth->SetStaticMesh(LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cylinder.Cylinder")));
    Plinth->SetRelativeLocation(FVector(0.f, 0.f, -4.f));
    Plinth->SetRelativeScale3D(FVector(1.65f, 1.65f, 0.08f));
    Plinth->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    if (UMaterialInterface* Stage = LoadObject<UMaterialInterface>(nullptr, TEXT("/Game/Viewer/Materials/M_Stage.M_Stage")))
        Plinth->SetMaterial(0, Stage);
    Plinth->RegisterComponent();
    StageMeshes.Add(Plinth);

    UDirectionalLightComponent* Key = NewObject<UDirectionalLightComponent>(this);
    Key->SetupAttachment(Root);
    Key->SetMobility(EComponentMobility::Movable);
    Key->SetRelativeRotation(FRotator(-38.f, -32.f, 0.f));
    Key->SetIntensity(3.5f);
    Key->SetLightColor(FLinearColor(1.f, 0.94f, 0.86f));
    Key->DynamicShadowDistanceMovableLight = 1000.f;
    Key->DynamicShadowCascades = 2;
    Key->RegisterComponent();
    StageLights.Add(Key);

    auto AddFill = [this, Root](FVector Location, FLinearColor Color, float Intensity)
    {
        UPointLightComponent* Light = NewObject<UPointLightComponent>(this);
        Light->SetupAttachment(Root);
        Light->SetMobility(EComponentMobility::Movable);
        Light->SetRelativeLocation(Location);
        Light->SetIntensity(Intensity);
        Light->SetAttenuationRadius(900.f);
        Light->SetLightColor(Color);
        Light->SetCastShadows(false);
        Light->RegisterComponent();
        StageLights.Add(Light);
    };
    AddFill(FVector(160.f, 200.f, 140.f), FLinearColor(0.62f, 0.77f, 1.f), 4200.f);
    AddFill(FVector(-150.f, -150.f, 210.f), FLinearColor(0.68f, 0.88f, 1.f), 6000.f);

    UPostProcessComponent* Post = NewObject<UPostProcessComponent>(this);
    StagePostProcess = Post;
    Post->SetupAttachment(Root);
    Post->bUnbound = true;
    Post->Settings.bOverride_AutoExposureMethod = true;
    Post->Settings.AutoExposureMethod = EAutoExposureMethod::AEM_Manual;
    Post->Settings.bOverride_AutoExposureBias = true;
    Post->Settings.AutoExposureBias = 1.f;
    Post->Settings.bOverride_MotionBlurAmount = true;
    Post->Settings.MotionBlurAmount = 0.f;
    Post->Settings.bOverride_BloomIntensity = true;
    Post->Settings.BloomIntensity = 0.12f;
    Post->Settings.bOverride_VignetteIntensity = true;
    Post->Settings.VignetteIntensity = 0.22f;
    Post->RegisterComponent();
}
